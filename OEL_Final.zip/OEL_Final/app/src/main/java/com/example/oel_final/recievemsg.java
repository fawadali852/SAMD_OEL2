package com.example.oel_final;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class recievemsg extends AppCompatActivity {

    TextView receiver_msg,receiver_msg2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recievemsg);

        receiver_msg = findViewById(R.id.received_value_id);
        receiver_msg2 = findViewById(R.id.received_value_id2);
        Intent intent = getIntent();
        String str = intent.getStringExtra("message_key");
        String str2 = intent.getStringExtra("message_key2");
        receiver_msg.setText(str);
        receiver_msg2.setText(str2);
    }
}