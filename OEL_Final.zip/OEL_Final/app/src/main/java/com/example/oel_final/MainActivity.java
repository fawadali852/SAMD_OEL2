package com.example.oel_final;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    Button send_button,signupc,signinc,btn1,btn2,btn3;
    EditText send_text,send_location;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn1= findViewById(R.id.button_citizen);
        btn1.setOnClickListener(v4->{
            setContentView(R.layout.sign_up_citizen);
            signupc=findViewById(R.id.button);
            signupc.setOnClickListener(v->{
                setContentView(R.layout.login_citizen);
                signinc=findViewById(R.id.login);

                signinc.setOnClickListener(v2->{
                    setContentView(R.layout.sendmsg);

                    send_button= findViewById(R.id.send);
                    send_text = findViewById(R.id.sendmsg);
                    send_location = findViewById(R.id.sendlocation);

                    send_button.setOnClickListener(v3->{
                        String str = send_text.getText().toString();

                        String str2 = send_location.getText().toString();
                        Intent intent = new Intent(getApplicationContext(), recievemsg.class);
                        intent.putExtra("message_key", str);
                        intent.putExtra("message_key2", str2);
                        startActivity(intent);
                    });
                });
            });
        });
        btn2= findViewById(R.id.button_Emer);
        btn2.setOnClickListener(view -> {
            setContentView(R.layout.sign_up_emergencyresponder);
            btn3= findViewById(R.id.button);
            btn3.setOnClickListener(view1 -> {
                setContentView(R.layout.login_emergencyresponder2);

            });
        });






    }
}